const DEFAULT_PORT = 4455;
let ws = null;
let wsAuthenticated = false;
let wsConnecting = false;
let lastError = '';
let wsPort = DEFAULT_PORT;
let widgetStyle = 'classic';

const tracks = new Map();
const lastUpdate = new Map();
let lastSource = '';
let currentTrackData = null;
let activeTabId = null;
let reconnectTimer = null;
let connectFailures = 0;
let lastNoMusicSent = 0;
let lastSentKind = '';
let settingsReady = false;

function scheduleConnect() {
  if (reconnectTimer) return;
  var delay = Math.min(300 * Math.pow(2, connectFailures), 5000);
  connectFailures = Math.min(connectFailures + 1, 6);
  reconnectTimer = setTimeout(() => { reconnectTimer = null; connect(); }, delay);
}

function connect() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (wsConnecting) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  wsConnecting = true;

  if (ws) { try { ws.close(); } catch (e) {} }

  const sock = new WebSocket('ws://127.0.0.1:' + wsPort);
  ws = sock;
  wsAuthenticated = false;

  sock.onopen = () => {};

  sock.onmessage = async (event) => {
    if (ws !== sock) return;
    try {
      const msg = JSON.parse(event.data);

      if (msg.op === 0) {
        const serverRpcVersion = msg.d.rpcVersion;
        const identify = { op: 1, d: { rpcVersion: serverRpcVersion, eventSubscriptions: 0x7FFFFFFF } };

        if (msg.d.authentication) {
          lastError = 'auth_required';
          sock.close();
          if (ws === sock) { ws = null; wsConnecting = false; }
          return;
        }

        try { sock.send(JSON.stringify(identify)); } catch (e) {
          lastError = 'send_failed';
          sock.close();
          if (ws === sock) { ws = null; wsConnecting = false; }
        }
      } else if (msg.op === 2) {
        wsAuthenticated = true;
        wsConnecting = false;
        connectFailures = 0;
        lastError = '';
        pickAndSend(true);
      }
    } catch (e) {}
  };

  sock.onclose = (event) => {
    if (ws !== sock) return;
    ws = null;
    wsAuthenticated = false;
    wsConnecting = false;
    if (event.code && event.code !== 1000 && event.code !== 1006) lastError = 'close_' + event.code;
    if (!lastError && event.code !== 1000) lastError = 'connection_error';
    scheduleConnect();
  };

  sock.onerror = () => {
    if (ws !== sock) return;
    wsConnecting = false;
    try { sock.close(); } catch (e) {}
    ws = null;
    wsAuthenticated = false;
    lastError = 'connection_error';
    scheduleConnect();
  };

  setTimeout(() => {
    if (ws === sock && ws.readyState === WebSocket.CONNECTING) {
      lastError = 'timeout';
      try { sock.close(); } catch (e) {}
      if (ws === sock) { ws = null; wsAuthenticated = false; wsConnecting = false; }
      scheduleConnect();
    }
  }, 4000);
}

function send(data) {
  if (!ws || ws.readyState !== WebSocket.OPEN || !wsAuthenticated) return;
  data._style = widgetStyle;

  try {
    ws.send(JSON.stringify({
      op: 6,
      d: {
        requestType: 'BroadcastCustomEvent',
        requestId: '' + Date.now() + Math.random(),
        requestData: { eventData: data }
      }
    }));
  } catch (e) {}
}

function trackWeight(track) {
  return (track.data.state === 'playing' ? 2 : 1) + (track.data.muted ? 0 : 2);
}

function pickAndSend(force) {
  var best = null;
  var bestTabId = null;
  for (const [tabId, track] of tracks) {
    if (!best) { best = track; bestTabId = tabId; continue; }
    var w = trackWeight(track);
    var bw = trackWeight(best);
    if (w > bw) { best = track; bestTabId = tabId; continue; }
    if (w < bw) continue;
    var ts = track.data.state === 'playing' ? (track.playingSince || 0) : (track.pausedAt || 0);
    var bts = best.data.state === 'playing' ? (best.playingSince || 0) : (best.pausedAt || 0);
    if (ts > bts) { best = track; bestTabId = tabId; continue; }
    if (ts < bts) continue;
    if ((lastUpdate.get(tabId) || 0) > (lastUpdate.get(bestTabId) || 0)) {
      best = track;
      bestTabId = tabId;
    }
  }

  // Прилипчивость: новый играющий источник со звуком не перебивает уже
  // играющий источник со звуком. Смена — только на строго более высокий ранг.
  if (activeTabId != null && tracks.has(activeTabId)) {
    var cur = tracks.get(activeTabId);
    if (!best || trackWeight(cur) >= trackWeight(best)) { best = cur; bestTabId = activeTabId; }
  }

  if (best) {
    activeTabId = bestTabId;
    lastSource = best.source;
    currentTrackData = best.data;
    lastSentKind = 'track';
    send(best.data);
  } else {
    activeTabId = null;
    lastSource = '';
    currentTrackData = { error: 'no_music' };
    var now = Date.now();
    if (force || lastSentKind !== 'none' || now - lastNoMusicSent > 15000) {
      lastNoMusicSent = now;
      lastSentKind = 'none';
      send(currentTrackData);
    }
  }
}

const UPDATE_API_URL = 'https://api.github.com/repos/Stepanchikkk/music-widget-obs/releases/latest';
const RELEASES_URL = 'https://github.com/Stepanchikkk/music-widget-obs/releases/latest';
const UPDATE_INTERVAL_MS = 24 * 60 * 60 * 1000;

function cmpVersions(a, b) {
  var pa = String(a).replace(/^v/i, '').split('.');
  var pb = String(b).replace(/^v/i, '').split('.');
  for (var i = 0; i < Math.max(pa.length, pb.length); i++) {
    var x = parseInt(pa[i], 10) || 0;
    var y = parseInt(pb[i], 10) || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function setUpdateBadge(has) {
  try {
    chrome.action.setBadgeText({ text: has ? '1' : '' });
    if (has) chrome.action.setBadgeBackgroundColor({ color: '#e05252' });
  } catch (e) {}
}

function checkForUpdate(force) {
  return new Promise(function(resolve) {
    chrome.storage.local.get({ updateAvailable: false, latestVersion: '', releaseUrl: RELEASES_URL, lastUpdateCheck: 0 }, function(items) {
      var now = Date.now();
      var cached = { updateAvailable: !!items.updateAvailable, latestVersion: items.latestVersion || '', releaseUrl: items.releaseUrl || RELEASES_URL };
      if (!force && now - (items.lastUpdateCheck || 0) < UPDATE_INTERVAL_MS) {
        setUpdateBadge(cached.updateAvailable);
        resolve(cached);
        return;
      }
      fetch(UPDATE_API_URL, { cache: 'no-store', headers: { 'Accept': 'application/vnd.github+json' } })
        .then(function(r) { return r.json(); })
        .then(function(rel) {
          var latest = (rel && rel.tag_name) ? String(rel.tag_name) : '';
          var url = (rel && rel.html_url) ? String(rel.html_url) : RELEASES_URL;
          var has = latest ? cmpVersions(latest, chrome.runtime.getManifest().version) > 0 : false;
          chrome.storage.local.set({ updateAvailable: has, latestVersion: latest, releaseUrl: url, lastUpdateCheck: now });
          setUpdateBadge(has);
          resolve({ updateAvailable: has, latestVersion: latest, releaseUrl: url });
        })
        .catch(function() {
          setUpdateBadge(cached.updateAvailable);
          resolve(cached);
        });
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'mediaSessionUpdate') {
    const tabId = sender.tab?.id;
    if (!tabId) return;
    if (settingsReady) connect();
    chrome.tabs.get(tabId, () => {
      if (chrome.runtime.lastError) return;
      var prev = tracks.get(tabId);
      var data = msg.data;
      var playingSince = 0;
      if (data.state === 'playing' && (!prev || prev.data.state !== 'playing'))
        playingSince = Date.now();
      else if (prev)
        playingSince = prev.playingSince || 0;
      var pausedAt = 0;
      if (data.state === 'paused' && (!prev || prev.data.state !== 'paused'))
        pausedAt = Date.now();
      else if (prev)
        pausedAt = prev.pausedAt || 0;
      tracks.set(tabId, {
        data: data,
        source: getHostname(sender.tab?.url || ''),
        playingSince: playingSince,
        pausedAt: pausedAt,
        audible: prev ? prev.audible : undefined,
        tabMuted: prev ? prev.tabMuted : undefined,
        discarded: prev ? prev.discarded : false,
        lastPing: prev ? prev.lastPing : 0
      });
      lastUpdate.set(tabId, Date.now());
      pickAndSend(false);
    });
    return;
  }

  if (msg.type === 'trackEnded') {
    const tabId = sender.tab?.id;
    if (tabId && tracks.has(tabId)) {
      const ending = tracks.get(tabId);
      clearTimeout(ending.removeTimer);
      ending.removeTimer = setTimeout(() => {
        if (tracks.get(tabId) !== ending) return;
        tracks.delete(tabId);
        lastUpdate.delete(tabId);
        if (activeTabId === tabId) activeTabId = null;
        pickAndSend(true);
      }, 1500);
    } else {
      pickAndSend(true);
    }
    return;
  }

  if (msg.type === 'checkUpdate') {
    checkForUpdate(false).then(function(res) { sendResponse(res); });
    return true;
  }

  if (msg.type === 'getStatus') {
    sendResponse({
      connected: ws !== null && wsAuthenticated,
      track: currentTrackData && !currentTrackData.error ? currentTrackData : null,
      source: lastSource,
      tabs: tracks.size,
      style: widgetStyle,
      debug: {
        wsState: ws ? ws.readyState : -1,
        wsAuth: wsAuthenticated,
        wsConn: wsConnecting,
        error: lastError,
        port: wsPort
      }
    });
    return true;
  }

  if (msg.type === 'reconnect') {
    if (msg.wsPort !== undefined) wsPort = msg.wsPort;
    if (ws) { try { ws.close(); } catch (e) {} }
    ws = null;
    wsAuthenticated = false;
    wsConnecting = false;
    connectFailures = 0;
    connect();
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'setStyle') {
    widgetStyle = msg.style;
    chrome.storage.local.set({ widgetStyle: msg.style });
    pickAndSend(true);
    sendResponse({ ok: true });
    return true;
  }
});

chrome.alarms.create('heartbeat', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'heartbeat') {
    connect();
    sweepTabs();
    pickAndSend(true);
    checkForUpdate(false);
  }
});

function getHostname(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

chrome.storage.local.get({ wsPort: DEFAULT_PORT, widgetStyle: 'classic' }, (items) => {
  wsPort = items.wsPort;
  widgetStyle = items.widgetStyle || 'classic';
  settingsReady = true;
  connect();
  checkForUpdate(false);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tracks.has(tabId)) {
    tracks.delete(tabId);
    lastUpdate.delete(tabId);
    if (activeTabId === tabId) activeTabId = null;
    pickAndSend(true);
  }
});

// Обновления вкладки: выгрузка (discarded) и наличие звука. Навигацию здесь
// не трогаем — иначе любой переход по странице даёт ложную заглушку.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!tracks.has(tabId)) return;
  const track = tracks.get(tabId);
  if (changeInfo.discarded === true) {
    if (track.data.state === 'playing') { track.data.state = 'paused'; track.pausedAt = track.pausedAt || Date.now(); }
    track.discarded = true;
    pickAndSend(false);
  }
  if (changeInfo.audible !== undefined) track.audible = changeInfo.audible;
  if (changeInfo.mutedInfo) track.tabMuted = !!changeInfo.mutedInfo.muted;
});

// Пока вкладка существует — держим её последнее состояние. Молчание не смерть.
function sweepTabs() {
  const now = Date.now();
  tracks.forEach((track, tabId) => {
    chrome.tabs.get(tabId).then((tab) => {
      track.audible = !!tab.audible;
      track.tabMuted = !!(tab.mutedInfo && tab.mutedInfo.muted);
      track.discarded = !!tab.discarded;
      if (track.discarded && track.data.state === 'playing') {
        track.data.state = 'paused';
        track.pausedAt = track.pausedAt || now;
      }
      if (now - (lastUpdate.get(tabId) || 0) > 4000) {
        if (!track.audible && !track.tabMuted && track.data.state === 'playing') {
          track.data.state = 'paused';
          track.pausedAt = track.pausedAt || now;
        }
        pingTab(tabId, track, now);
      }
    }).catch(() => {
      tracks.delete(tabId);
      lastUpdate.delete(tabId);
      if (activeTabId === tabId) activeTabId = null;
    });
  });
}

function pingTab(tabId, track, now) {
  if (track.discarded) return;
  if (now - (track.lastPing || 0) < 10000) return;
  track.lastPing = now;
  chrome.tabs.sendMessage(tabId, { type: 'ping' }).catch(() => {
    chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['content.js'] }).catch(() => {});
  });
}

setInterval(() => {
  sweepTabs();
  pickAndSend(false);
}, 4000);

// Inject content.js into all existing tabs so they don't need F5
function injectContent(tabs) {
  for (const tab of tabs) {
    if (!tab.id) continue;
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    }).catch(() => {});
  }
}
chrome.tabs.query({}, (tabs) => {
  if (tabs && tabs.length > 0) { injectContent(tabs); return; }
  chrome.windows.getAll({ populate: true }, (windows) => {
    const all = [];
    for (const w of windows) { if (w.tabs) all.push(...w.tabs); }
    if (all.length > 0) injectContent(all);
  });
});